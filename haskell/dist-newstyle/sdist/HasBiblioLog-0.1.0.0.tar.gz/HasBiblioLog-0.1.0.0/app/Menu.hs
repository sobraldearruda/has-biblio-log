{-# LANGUAGE OverloadedStrings #-}

module Menu (
    menu,
    insertItemPrompt,
    listItems,
    updateItemPrompt,
    deleteItemPrompt
) where

import Database (insertItem, getItems, updateItem, deleteItem)
import Database.PostgreSQL.Simple (Connection)
import System.IO (hFlush, stdout)

menu :: Connection -> IO ()
menu connect = do
    putStrLn "\nMENU:"
    putStrLn "1. USUÁRIOS"
    putStrLn "2. ACERVO BIBLIOGRÁFICO"
    putStrLn "3. EMPRÉSTIMOS"
    putStrLn "4. SAIR"
    putStr "\nDigite sua escolha: "
    hFlush stdout
    choice <- getLine
    case choice of
        "1" -> menuUsers connect
        "2" -> menuArchive connect
        "3" -> menuBorrowing connect
        "4" -> do
            putStrLn "\n📚 HasBiblioLog 📚"
            return ()
        _   -> putStrLn "\nOpção inválida. Tente novamente."

menuUsers :: Connection -> IO ()
menuUsers connect = do
    putStrLn "\n1. CADASTRAR USUÁRIO"
    putStrLn "2. ATUALIZAR USUÁRIO"
    putStrLn "3. VISUALIZAR USUÁRIO"
    putStrLn "4. LISTAR USUÁRIOS"
    putStrLn "5. REMOVER USUÁRIO"
    putStrLn "6. RETORNAR AO MENU"
    putStr "\nDigite sua escolha: "
    hFlush stdout
    choice <- getLine
    case choice of
        "1" -> insertItemPrompt connect
        "2" -> updateItemPrompt connect
        "3" -> listItems connect
        "4" -> listItems connect
        "5" -> deleteItemPrompt connect
        "6" -> backToMenu connect
        "7" -> do
            putStrLn "\n📚 HasBiblioLog 📚"
            return ()
        _   -> putStrLn "\nOpção inválida. Tente novamente."

menuArchive :: Connection -> IO ()
menuArchive connect = do
    putStrLn "\n1. CADASTRAR LIVRO"
    putStrLn "2. ATUALIZAR LIVRO"
    putStrLn "3. VISUALIZAR LIVRO"
    putStrLn "4. LISTAR LIVROS"
    putStrLn "5. REMOVER LIVRO"
    putStrLn "6. RETORNAR AO MENU"
    putStr "\nDigite sua escolha: "
    hFlush stdout
    choice <- getLine
    case choice of
        "1" -> insertItemPrompt connect
        "2" -> updateItemPrompt connect
        "3" -> listItems connect
        "4" -> listItems connect
        "5" -> deleteItemPrompt connect
        "6" -> backToMenu connect
        "7" -> do
            putStrLn "\n📚 HasBiblioLog 📚"
            return ()
        _   -> putStrLn "\nOpção inválida. Tente novamente."

menuBorrowing :: Connection -> IO ()
menuBorrowing connect = do
    putStrLn "\n1. CADASTRAR EMPRÉSTIMO"
    putStrLn "2. ATUALIZAR EMPRÉSTIMO"
    putStrLn "3. VISUALIZAR EMPRÉSTIMO"
    putStrLn "4. LISTAR EMPRÉSTIMOS"
    putStrLn "5. REMOVER EMPRÉSTIMO"
    putStrLn "6. RETORNAR AO MENU"
    putStr "\nDigite sua escolha: "
    hFlush stdout
    choice <- getLine
    case choice of
        "1" -> insertItemPrompt connect
        "2" -> updateItemPrompt connect
        "3" -> listItems connect
        "4" -> listItems connect
        "5" -> deleteItemPrompt connect
        "6" -> backToMenu connect
        "7" -> do
            putStrLn "\n📚 HasBiblioLog 📚"
            return ()
        _   -> putStrLn "\nOpção inválida. Tente novamente."

-- Retorna ao Menu de opções
backToMenu :: Connection -> IO ()
backToMenu connect = do
    menu connect

insertItemPrompt :: Connection -> IO ()
insertItemPrompt connect = do
    putStr "Digite o nome do item: "
    hFlush stdout
    name <- getLine
    insertItem connect name

listItems :: Connection -> IO ()
listItems connect = do
    items <- getItems connect
    putStrLn "Itens no banco de dados:"
    mapM_ putStrLn items

updateItemPrompt :: Connection -> IO ()
updateItemPrompt connect = do
    putStr "Digite o ID do item a ser atualizado: "
    hFlush stdout
    idStr <- getLine
    let itemId = read idStr :: Int
    putStr "Digite o novo nome do item: "
    hFlush stdout
    newName <- getLine
    updateItem connect itemId newName

deleteItemPrompt :: Connection -> IO ()
deleteItemPrompt connect = do
    putStr "Digite o ID do item a ser deletado: "
    hFlush stdout
    idStr <- getLine
    let itemId = read idStr :: Int
    deleteItem connect itemId
